import React from "react";
import ReactDOM from "react-dom/client";
import FlashcardsApp from "./FlashcardsApp";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <FlashcardsApp />
  </React.StrictMode>
);
