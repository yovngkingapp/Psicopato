
import { useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shuffle } from "lucide-react";

const data = {
  "Trastorno Específico del Aprendizaje": [
    { front: "Criterio A", back: "Dificultades en el aprendizaje (mínimo 1 síntoma persistente ≥ 6 meses): 1. Lectura imprecisa/lenta/esforzada. 2. Problemas para comprender lo leído. 3. Dificultades ortográficas. 4. Problemas en expresión escrita. 5. Dificultades con el sentido numérico/cálculo. 6. Problemas en razonamiento matemático." },
    { front: "Criterio B", back: "Aptitudes académicas están cuantificablemente por debajo de lo esperado, interfiriendo con el rendimiento. Confirmado por pruebas estandarizadas o historia clínica." },
    { front: "Criterio C", back: "Los síntomas aparecen en edad escolar, pero pueden no ser evidentes hasta que aumentan las exigencias académicas." },
    { front: "Criterio D", back: "Las dificultades no se explican mejor por discapacidad intelectual, sensorial, trastornos mentales, adversidad psicosocial, idioma o mala enseñanza." },
    { front: "Especificadores", back: "Leve: Puede compensar con apoyo. - Moderado: Requiere apoyo regular e intervenciones. - Grave: Necesita apoyo intensivo; afecta varias áreas." },
    { front: "Especificadores de tipo", back: "Dificultad de lectura 315.00 (f81.0) Dislexia – Dificultad expresión escrita 315.2 (F81.1) – Dificultad matemática 315.1 (F81.2) Discalculia" },
  ],
  "Trastorno Negativista Desafiante": [
    { front: "Criterio A", back: "Patrón de enfado/desafío/venganza (≥ 6 meses, ≥ 4 síntomas) en al menos 1 contexto no fraternal: pierde la calma, se molesta fácilmente, está resentido, discute con figuras de autoridad, desobedece, molesta, culpa a otros. Vengativo/rencoroso ≥2 veces en 6 meses." },
    { front: "Criterio B", back: "Provoca malestar clínico en sí mismo u otros, o afecta el rendimiento social, académico, ocupacional." },
    { front: "Criterio C", back: "No se explica por trastorno psicótico, afectivo, sustancia, ni desregulación emocional." },
    { front: "Especificar gravedad", back: "Leve: Solo en un contexto - Moderado: En dos contextos - Grave: En tres o más contextos" },
  ]
};

export default function FlashcardsApp() {
  const [flipped, setFlipped] = useState({});
  const [shuffled, setShuffled] = useState({});

  const handleFlip = (tr, idx) => {
    setFlipped((prev) => ({ ...prev, [tr + idx]: !prev[tr + idx] }));
  };

  const handleShuffle = (tr) => {
    const shuffledCards = [...data[tr]].sort(() => 0.5 - Math.random());
    setShuffled((prev) => ({ ...prev, [tr]: shuffledCards }));
    setFlipped({});
  };

  return (
    <div className="min-h-screen bg-[#1a1a1a] text-white p-4">
      <h1 className="text-3xl font-bold text-red-500 mb-4 text-center">Flashcards Trastornos DSM-5</h1>
      <Tabs defaultValue={Object.keys(data)[0]} className="w-full">
        <TabsList className="flex flex-wrap justify-center mb-4">
          {Object.keys(data).map((tr) => (
            <TabsTrigger key={tr} value={tr} className="text-red-400 hover:text-white">
              {tr}
            </TabsTrigger>
          ))}
        </TabsList>
        {Object.keys(data).map((tr) => (
          <TabsContent key={tr} value={tr} className="space-y-4">
            <div className="flex justify-end">
              <Button variant="outline" className="text-red-400 border-red-400 hover:bg-red-700" onClick={() => handleShuffle(tr)}>
                <Shuffle className="w-4 h-4 mr-2" /> Mezclar
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {(shuffled[tr] || data[tr]).map((card, idx) => (
                <Card key={idx} onClick={() => handleFlip(tr, idx)} className="cursor-pointer bg-[#2a2a2a] hover:bg-[#3a3a3a]">
                  <CardContent className="p-4 text-center text-white">
                    {flipped[tr + idx] ? card.back : card.front}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
